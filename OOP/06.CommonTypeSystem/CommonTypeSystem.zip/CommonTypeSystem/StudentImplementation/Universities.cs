﻿namespace StudentImplementation
{
    public enum Universities
    {
        None,
        MassachusettsInstituteofTechnology,
        Harvard,
        SoftwareUniversity,
        TelerikAcademy,
        SofiaUniversity
    }
}