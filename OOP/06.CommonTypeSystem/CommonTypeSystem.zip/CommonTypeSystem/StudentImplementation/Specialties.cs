﻿namespace StudentImplementation
{
    public enum Specialties
    {
        None,
        AppliedMathematics,
        Informatics,
        Physics,
        Polytics,
        ComputerScience,
        Law,
        Medicine,
        History,
        Astronomy
    }
}