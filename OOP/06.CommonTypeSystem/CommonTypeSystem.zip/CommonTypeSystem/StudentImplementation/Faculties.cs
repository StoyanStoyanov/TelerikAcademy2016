﻿namespace StudentImplementation
{
    public enum Faculties
    {
        None,
        MathematicsandInformatics,
        AppliedSciences,
        Journalism,
        Physics
    }
}