﻿namespace Ex03AnimalsHierarchy
{
    public interface ISound
    {
        void ProduceSound();
    }
}