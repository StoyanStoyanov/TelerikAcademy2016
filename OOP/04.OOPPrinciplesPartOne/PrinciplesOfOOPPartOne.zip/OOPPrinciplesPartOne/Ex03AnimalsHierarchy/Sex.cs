﻿namespace Ex03AnimalsHierarchy
{
    public enum Sex
    {
        Male,
        Female
    }
}